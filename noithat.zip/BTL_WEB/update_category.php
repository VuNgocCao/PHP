<?php
	require "config.php";
	
	//update
	if(isset($_POST["update"]))
	{
		$cate_id = $_POST["cate_id"];
		$cate_name = $_POST["Cate_Name"];
		
		//echo $cate_id;
		$sql = "update category set cate_name=N'".$cate_name."' where cate_id=".$cate_id;

		if ($conn->query($sql) === TRUE) {
		  header("Location: index.php");
		} else {
		  echo "Error update record: " . $conn->error;
		}
	}
?>

<html>
	<head>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
	</head>
	<body>
		<div class="container">
			<h1 style="text-align:center;font-size:24px;">Cập nhật danh mục sản phẩm</h1>
			<div class="row">
				<form action="update_category.php" class="col-6" method="post">
					<?php
					
						if(isset($_GET["id"]))
						{
							$id = $_GET["id"];
							//echo $id;
							$sql = "SELECT * FROM category where cate_id=".$id;
							$result = mysqli_query($conn, $sql);

							if (mysqli_num_rows($result) > 0) 
							{
								// output data of each row
								while($row = mysqli_fetch_assoc($result)) 
								{	
									echo "<input type='hidden' name='cate_id' value='".$row["cate_id"]."'>";
									echo "Cập nhật tên danh mục";
									echo "<input type='text' class='form-control' name='Cate_Name' value='".$row["cate_name"]."'>";
								}
							}
						}
					?>
					
					<input type="submit" name="update" value="Cập nhật" class="btn btn-primary">
				</form>
			</div>
			
		</div>
		
	</body>
</html>